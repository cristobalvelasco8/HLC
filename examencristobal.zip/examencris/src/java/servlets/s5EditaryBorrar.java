
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "s5EditaryBorrar", urlPatterns = {"/s5EditaryBorrar"})
public class s5EditaryBorrar extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Editar</title></head>");
        int i = 1;
        ResultSet rs4 = new l1.ejecuta("SELECT * FROM coche").getResult();

        try {
            while (rs4.next()) {
                if (request.getParameter("e" + i) != null) {
                    out.println("<body><div>");
                    out.println("<h1>Editar Campos</h1>");
                    out.println("<table>");
                    rs4.absolute(i);
                    out.println("<form action='s7SalvarCambios' method='POST'>");
                    out.println("<tr><td>MATRICULA</td><td><input type='string' name='matricula' value='" + rs4.getString(1) + "' required></td></tr><br>");
                    out.println("<tr><td>MODELO</td><td><input type='string' name='modelo' value='" + rs4.getString(2) + "' required></td></tr><br>");
                    out.println("<tr><td>PROPIETARIO</td><td><input type='string' name='propietario' value='" + rs4.getString(3) + "' required></td></tr><br>");
                    out.println("<tr><td><input type='submit' name='guardar" + i + "' value='Guardar Cambios'></td></tr>");
                    out.println("</table>");
                    out.println("</form>");
                    out.println("<a href='index.jsp'>Inicio</a>");
                    out.println("<a href='admincoches.jsp'>Volver</a>");
                    out.println("</div></body>");
                } else {
                    if (request.getParameter("b" + i) != null) {
                        rs4.absolute(i);
                        rs4.deleteRow();
                        out.println("Registro eliminado");
                        out.println("<a href='admincoches.jsp'>Volver</a>");
                    }
                }
                i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(s5EditaryBorrar.class.getName()).log(Level.SEVERE, null, ex);
        }




    }


}
