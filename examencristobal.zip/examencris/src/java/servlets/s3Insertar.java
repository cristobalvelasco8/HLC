/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "s3Insertar", urlPatterns = {"/s3Insertar"})
public class s3Insertar extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        ResultSet rs1 = new l1.ejecuta("select * from cliente").getResult();
        try {
            rs1.moveToInsertRow();
            rs1.updateString(1, (request.getParameter("dni")));
            rs1.updateString(2, (request.getParameter("nombre")));
            rs1.updateString(3, (request.getParameter("localidad")));
            rs1.insertRow();
        } catch (SQLException ex) {
            Logger.getLogger(s3Insertar.class.getName()).log(Level.SEVERE, null, ex);
        }
        response.sendRedirect("admin.jsp");

    }


}
