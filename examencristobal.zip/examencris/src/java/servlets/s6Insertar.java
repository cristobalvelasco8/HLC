/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "s6Insertar", urlPatterns = {"/s6Insertar"})
public class s6Insertar extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        ResultSet rs1 = new l1.ejecuta("select * from coche").getResult();
        try {
            rs1.moveToInsertRow();
            rs1.updateString(1, (request.getParameter("matricula")));
            rs1.updateString(2, (request.getParameter("modelo")));
            rs1.updateString(3, (request.getParameter("propietario")));
            rs1.insertRow();
        } catch (SQLException ex) {
            Logger.getLogger(s6Insertar.class.getName()).log(Level.SEVERE, null, ex);
        }
        response.sendRedirect("admincoches.jsp");

    }


}
