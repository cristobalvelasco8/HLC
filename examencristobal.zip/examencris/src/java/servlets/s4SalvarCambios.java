/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "s4SalvarCambios", urlPatterns = {"/s4SalvarCambios"})
public class s4SalvarCambios extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Editar</title></head>");
        out.println("<body><div>");
        int i = 1;
        ResultSet rs5 = new l1.ejecuta("SELECT * FROM cliente").getResult();
        try {
            while (rs5.next()) {
                if (request.getParameter("guardar" + i) != null) {
                    rs5.absolute(i);
                    rs5.updateString(1,request.getParameter("dni"));
                    rs5.updateString(2, (request.getParameter("nombre")));
                    rs5.updateString(3, (request.getParameter("localidad")));
                    rs5.updateRow();
                }
                i++;

            }
            out.println("Registro insertado");
            response.sendRedirect("admin.jsp");
            out.println("</div></body>");
        } catch (SQLException ex) {
            Logger.getLogger(s4SalvarCambios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
