/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l1;


import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ejecuta {
    
    Connection conexion;
    Statement instruccion;
    ResultSet result;
    
    public ejecuta(String sentenciasql) {
        
        String url = "jdbc:mysql://localhost:3306/recupera?useTimeZone=true&ServerTimezone=UTC&autoReconnect=true&useSSL=false";
        
        try {
 Class.forName("com.mysql.jdbc.Driver");
 this.conexion = (Connection) DriverManager.getConnection(url, "cristobal", "1234");
 this.instruccion = (Statement) conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
 ResultSet.CONCUR_UPDATABLE);
 this.result = instruccion.executeQuery(sentenciasql);

 } catch (ClassNotFoundException | SQLException  e) {
 }
        
    }

    public ResultSet getResult() {
        return result;
    }
    
    
    
    
    
    
    
}
