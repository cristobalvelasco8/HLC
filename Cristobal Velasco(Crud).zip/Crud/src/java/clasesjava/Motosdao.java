package clasesjava;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.*;  
import java.sql.*;  

public class Motosdao {
    
    public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/moto?serverTimezone=UTC","cristobal","1234");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
    public static int save(Motos m){  
        int status=0;  
        try{  
            Connection con=Motosdao.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into motos(marca,cv,km) values (?,?,?)");  
            ps.setString(1,m.getMarca());  
            ps.setInt(2,m.getCv());  
            ps.setInt(3,m.getKm());   
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int update(Motos m){  
        int status=0;  
        try{  
            Connection con=Motosdao.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update motos set marca=?,cv=?,km=? where id=?");  
            ps.setString(1,m.getMarca());  
            ps.setInt(2,m.getCv());  
            ps.setInt(3,m.getKm());   
            ps.setInt(4,m.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=Motosdao.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from motos where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Motos getMotosById(int id){  
        Motos g=new Motos();  
          
        try{  
            Connection con=Motosdao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from motos where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                g.setId(rs.getInt(1));  
                g.setMarca(rs.getString(2));  
                g.setCv(rs.getInt(3));  
                g.setKm(rs.getInt(4));   
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return g;  
    }  
    public static List<Motos> getAllMotos(){  
        List<Motos> list=new ArrayList<Motos>();  
          
        try{  
            Connection con=Motosdao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from motos");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Motos m=new Motos();  
                m.setId(rs.getInt(1));  
                m.setMarca(rs.getString(2));  
                m.setCv(rs.getInt(3));  
                m.setKm(rs.getInt(4));    
                list.add(m);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}  
    
    
