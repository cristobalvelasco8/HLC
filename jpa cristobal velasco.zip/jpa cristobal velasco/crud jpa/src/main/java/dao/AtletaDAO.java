package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import model.Atleta;



public class AtletaDAO {

    protected EntityManager em;
    private EntityManagerFactory emf = null;

    public AtletaDAO() {
        emf = Persistence.createEntityManagerFactory("HibernatePU");
    }

    public void listar() {
        // Consulta a ejecutar
        // No necesitamos crear una nueva transaccion
        String hql = "SELECT a FROM Atleta a";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Atleta> list = query.getResultList();
        query = em.createNamedQuery("Atleta.findAll");
        for (Atleta n : list) {
            System.out.println(n);
        }
        em.close();
        emf.close();
    }

    public List<Atleta> listarAtletas() {
        // Consulta a ejecutar
        String hql = "SELECT a FROM Atleta a";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Atleta> n2 = query.getResultList();
        em.close();
        emf.close();
        return n2;
    }

    public void insertar(Atleta atleta) {
        try {
            em = getEntityManager();
            // Iniciamos una transaccion
            em.getTransaction().begin();
            // Insertamos la nueva avion
            em.persist(atleta);
            // Terminamos la transaccion
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error al insetar objeto:" + ex.getMessage());
            // ex.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
                emf.close();
            }
        }
    }

    public void actualizar(Atleta atleta) {
        try {
            em = getEntityManager();
            // Iniciamos una transaccion
            em.getTransaction().begin();
            // Actualizamos al objeto persona
            em.merge(atleta);
            // Terminamos la transaccion
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error al actualizar objeto:" + ex.getMessage());
            // ex.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
                emf.close();
            }
        }
    }

        public void eliminar(Atleta atleta) {
        try {
            em = getEntityManager();
            // Iniciamos una transaccion
            em.getTransaction().begin();
            // Sincronizamos y eliminamos a la avion
            em.remove(em.merge(atleta));
            // Terminamos la transaccion
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error al eliminar objeto:" + ex.getMessage());
            // ex.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Atleta buscarPorId(int id) {
        em = getEntityManager();
        Atleta a2 = em.find(Atleta.class, id);
        em.close();
        emf.close();
        return a2;
    }


    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

}