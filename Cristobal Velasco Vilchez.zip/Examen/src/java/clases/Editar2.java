package clases;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cristobal
 */

import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/Editar2")  
public class Editar2 extends HttpServlet {
     protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        int id=Integer.parseInt(request.getParameter("id"));  
        String Equipo=request.getParameter("equipo");  
        int Puntos=Integer.parseInt(request.getParameter("puntos"));  
        int Victorias=Integer.parseInt(request.getParameter("victorias"));  
        int Empates=Integer.parseInt(request.getParameter("victorias")); 
        int Derrotas=Integer.parseInt(request.getParameter("victorias")); 
        int GolesF=Integer.parseInt(request.getParameter("golesf"));
        int GolesC=Integer.parseInt(request.getParameter("golesC")); 
          
        Futbol m=new Futbol();  
        m.setId(id);  
        m.setEquipo(Equipo);  
        m.setPuntos(Puntos);
        m.setPuntos(Victorias); 
        m.setPuntos(Empates); 
        m.setPuntos(Derrotas); 
        m.setPuntos(GolesF); 
        m.setPuntos(GolesC); 
          
          
        int status=Futboldao.update(m);  
        if(status>0){  
            response.sendRedirect("ViewServlet");  
        }else{  
            out.println("No se ha podido actualizar");  
        }  
          
        out.close();  
    }  
  
    
}
