package clases;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Futbol {
    private int id;  
    private String equipo;  
    private int puntos,victorias,Empates,Derrotas,GolesF,GolesC;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getVictorias() {
        return victorias;
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }
    
        public int getEmpates() {
        return Empates;
    }

    public void setEmpates(int Empates) {
        this.Empates = Empates;
    }
    
        
        public int getDerrotas() {
        return Derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.Derrotas = derrotas;
    }
   
            public int getGolesF() {
        return GolesF;
    }

    public void setGolesF(int GolesF) {
        this.GolesF = GolesF;
    }
    
                public int getGolesC() {
        return GolesC;
    }

    public void setGolesC(int GolesC) {
        this.GolesC = GolesC;
    }
   
   
    
    
}