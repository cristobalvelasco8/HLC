/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/ViewServlet")  
public class Ver extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.println("<a href='index.html'>Añadir nuevo equipo</a>");  
        out.println("<h1>Añadir nuevo equipo</h1>");  
          
        List<Futbol> list=Futboldao.getAllFutbol();  
          
        out.print("<table border='1' width='100%'");  
        out.print("<tr><th>Id</th><th>Equipo</th><th>Puntos</th><th>Victorias</th> <th>Empates</th> <th>Derrotas</th> <th>golesf</th> <th>golesc</th><th>Edit</th><th>Delete</th></tr>");  
        for(Futbol m:list){  
        out.print("<tr><td>"+m.getId()+"</td><td>"+m.getEquipo()+"</td><td>"+m.getPuntos()+"</td> <td>"+m.getVictorias()+ "</td> <td>"+m.getEmpates()+ "</td> <td>"+m.getDerrotas()+ "</td> <td>"+m.getGolesF()+ "</td> <td>"+m.getGolesC()+"</td><td><a href='EditServlet?id="+m.getId()+"'>edit</a></td>   <td><a href='DeleteServlet?id="+m.getId()+"'>delete</a></td></tr>");  
        }  
        out.print("</table>");  
          
        out.close();  
    }  
}  