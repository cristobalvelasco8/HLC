package clases;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.*;  
import java.sql.*;  

public class Futboldao {
    
    public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/futbol?serverTimezone=UTC","cristobal","1234");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
    public static int save(Futbol m){  
        int status=0;  
        try{  
            Connection con=Futboldao.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "select from equipos (,puntos,victorias,empates,derrotas,golesf,golesc) values (?,?,?,?,?,?,?)");  
            ps.setString(1,m.getEquipo());  
            ps.setInt(2,m.getPuntos());  
            ps.setInt(3,m.getVictorias());
            ps.setInt(4,m.getEmpates());  
            ps.setInt(5,m.getDerrotas());  
            ps.setInt(6,m.getGolesF());  
            ps.setInt(7,m.getGolesC());   
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int update(Futbol m){  
        int status=0;  
        try{  
            Connection con=Futboldao.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update futbol set equipo=?,puntos=?,victorias=? empates=? derrotas=? golesf=? golesc=? where id=?");  
                ps.setString(2,m.getEquipo());  
            ps.setInt(3,m.getPuntos());  
            ps.setInt(4,m.getVictorias());
            ps.setInt(5,m.getEmpates());  
            ps.setInt(6,m.getDerrotas());  
            ps.setInt(7,m.getGolesF());  
            ps.setInt(8,m.getGolesC());
            ps.setInt(1,m.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=Futboldao.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from equipo where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Futbol getFutbolById(int id){  
        Futbol m=new Futbol();  
          
        try{  
            Connection con=Futboldao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from futbol where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                m.setId(rs.getInt(1));  
                 m.setEquipo(rs.getString(2));  
                m.setPuntos(rs.getInt(3));  
                m.setVictorias(rs.getInt(4));
                m.setEmpates(rs.getInt(4)); 
                m.setDerrotas(rs.getInt(4)); 
                m.setGolesF(rs.getInt(4)); 
                m.setGolesC(rs.getInt(4));  
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return m;  
    }  
    public static List<Futbol> getAllFutbol(){  
        List<Futbol> list=new ArrayList<Futbol>();  
          
        try{  
            Connection con=Futboldao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from futbol");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Futbol m=new Futbol();  
                m.setId(rs.getInt(1));  
                m.setEquipo(rs.getString(2));  
                m.setPuntos(rs.getInt(3));  
                m.setVictorias(rs.getInt(4));
                m.setEmpates(rs.getInt(4)); 
                m.setDerrotas(rs.getInt(4)); 
                m.setGolesF(rs.getInt(4)); 
                m.setGolesC(rs.getInt(4)); 
                list.add(m);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}  
    
    